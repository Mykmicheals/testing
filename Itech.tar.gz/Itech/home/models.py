from django.db import models

class Phone(models.Model):
    name = models.CharField(max_length = 15)
    price = models.IntegerField()
    images = models.ImageField(upload_to = 'phone/',blank = True)

 

# Create your models here.
