from django import forms

class User_Register(forms.Form):
    user_name = forms.CharField(max_length=15 , label = 'username')
    email = forms.EmailField(label = 'email')
    password1 = forms.CharField(max_length=15)
    password2 = forms.CharField(max_length=15)