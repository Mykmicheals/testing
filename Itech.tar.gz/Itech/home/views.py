from django.shortcuts import render,redirect
from .models import Phone
from .forms import User_Register
from django.contrib.auth.models import User,auth
from django.contrib import messages


def index(request):
    first = Phone.objects.all()
    return render(request,'index.html',{'first':first})


def register(request):
    new_user = User_Register()
    if request.method=='POST':
        new_user = User_Register(request.POST)
        if new_user.is_valid():
            username = new_user.cleaned_data['user_name']
            email = new_user.cleaned_data['email']
            pass_word1 = new_user.cleaned_data['password1']
            pass_word2 = new_user.cleaned_data['password2']
            if pass_word1==pass_word2:
                if User.objects.filter(username=username).exists():
                    messages.info(request,'username taken')
                    return render(request,'register.html')
                elif User.objects.filter(email=email).exists():
                    messages.info(request,'email exists')
                    return render(request,'register.html')
                else:
                    User.objects.create_user(username,email)
            else:
                messages.info(request,'password taken')
                return render(request,'register.html')
    else:
        return render (request,'register.html',{'user':new_user})



# Create your views here.
